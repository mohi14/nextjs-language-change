import React, { useContext, useState } from 'react';
import { Modal } from 'react-bootstrap';
import { RegexContext } from '../contexts/RegexContext';

const ProfileSettings = ({ t }) => {

};

export default ProfileSettings;