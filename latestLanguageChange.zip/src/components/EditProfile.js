import React, { useState, useContext } from 'react';
import { toast } from 'react-toastify';
import { Modal } from 'react-bootstrap';
import { RegexContext } from '../contexts/RegexContext';
import useIsomorphicLayoutEffect from 'use-isomorphic-layout-effect';

const EditProfile = ({ t }) => {

};

export default EditProfile;
