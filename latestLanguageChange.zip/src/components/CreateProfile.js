import React, { useState, useContext } from 'react';
import { Modal } from 'react-bootstrap';
import { RegexContext } from '../contexts/RegexContext';
import { v4 as uuidv4 } from 'uuid';
import { toast } from 'react-toastify';

const CreateProfile = ({ t }) => {

};

export default CreateProfile;
